('dont scroll down, wouldnt want to spoil the game for yourself now would you...')
('Please go check out The credits file to the left. The people there deserve recognition')




























print ("FILE DOWNLOADING A DEMO CODE PJ by Evan")
print ("please wait")
import time
time.sleep(5)
import replit
import time
replit.clear()

a = 1

while a < 10:
    print(a)
    a += 1
    time.sleep(1)
    replit.clear()
print ("DISCLAIMER... NOT ALL CHOICES ARE AVAILAIBLE, FOR EXAMPLE RUN AND NO")
print ('Type (hi) to start, this game requires you to type exactly what is asked for ex: if it says yes, you have a few more options like Yes Maam Yes Sir and yes\n')
string = input('')
if string == ('hi'):
 replit.clear()
 print ('Hi!')
 string = input('Do YoU wAnT sOmE FrEe RoBuX mY gUy?\n')
if string == ('Yes Maam') or ('yes') or ('Yes') or ('YES') or ('Yes Sir'):
   print ('AlRiGhT fAm...')
   print ('HeReS tHe DoWnLoAd LiNkIo')
   print ('.')
   print ('.')
   print ('.')

   import colorama
   from colorama import Fore
   print (Fore.BLUE)
   print ("robuxgenerator.exe")
   string = input('\033[1;37;40m TYPE DOWNLOAD TO BEGIN DOWNLOADING .EXE FILE\033[0;37;40m \n')
   if string == ('DOWNLOAD') or ('download'):
    replit.clear()
    import time
    print ('download starting...')
    time.sleep(1)
    print ('1%')
    time.sleep(1)
    print ('25%')
    time.sleep(1)
    print ('35%')
    time.sleep(1)
    print ('65%')
    time.sleep(1)
    print ('99%')
    time.sleep(1)
    print ('100%')
    time.sleep(1)
    print ('DOWNLOAD COMPLETE')
    print ('Would you like to scan the item before running? ||RUNNING HARDWARE THAT YOU ARE NOT FAMILIAR WITH CAN HAVE MALICIOUS FILES LOCATED INSIDE, SCANNING IS HIGHLY RECOMMENDED||')
    string = input('type (scan) to scan the .exe file or type (run) to run the .exe file without scanning\n')
    if string == ('scan') or ('SCAN'):
      replit.clear()
      print ("||RUNNING HARDWARE THAT YOU ARE NOT FAMILIAR WITH CAN HAVE MALICIOUS FILES LOCATED INSIDE||")
      print ('SCANNING .EXE FILE')
      print ('1%')
      time.sleep(2.4)
      print ('75%')
      time.sleep(1.5)
      print ('100%')
      print ('SCAN COMPLETE...')
      print ('PLEASE WAIT A MOMENT WHILE WE PULL UP THE RESULTS...')
      time.sleep(4)
      replit.clear()
      print (Fore.RED)
      print ('WARNING MALWARE HAS BEEN DETECTED ON THE FOLLOWING .EXE FILE(S)...')
      time.sleep(2)
      print (Fore.RED)
      string = input('(robuxgenerator.exe) IS RECOMMENDED FOR DELETION, PLEASE TYPE (DELETE) TO DELETE MALICIOUS .EXE FILE')
      print (' ')
      if string == ('DELETE') or ('delete'):
        replit.clear()
        print ('robuxgenerator.exe HAS BEEN DELETED PERMENATELY')
        time.sleep(1)
        replit.clear()
        print ('THANKS FOR PLAYING MY DEMO CODE!!!')
        time.sleep(2)
        print ("the full code will be done by today!")
